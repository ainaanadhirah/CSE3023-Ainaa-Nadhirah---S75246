<%-- 
    Document   : index
    Created on : 16 Jun 2026, 4:14:10 PM
    Author     : MP2-4
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ include file="header.html" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>index</title>
    </head>
    <body>
        <h1></h1>
        
        <ul>
            <li><a href="<%=request.getContextPath()%>/book_session.jsp">Book Session</a></li>
            <li><a href="<%=request.getContextPath()%>/ScheduleServlet">Schedule Dashboard</a></li>
        </ul>
        <%@ include file="footer.jsp" %>
    </body>
</html>
