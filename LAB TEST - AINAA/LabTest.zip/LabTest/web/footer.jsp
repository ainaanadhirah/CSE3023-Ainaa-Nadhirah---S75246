<%-- 
    Document   : footer
    Created on : 16 Jun 2026, 4:09:59 PM
    Author     : MP2-4
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <style>
        body {
        margin: 0;
        padding: 0;
        }
        
        footer {
        background-color: pink;
        padding: 10px;
        text-align: center;
        }
        </style>
        
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>DriveSmart Academy</title>
    </head>
    <body>
        <hr>
        <footer>
            <p>&copy; 2026 DriveSmart Academy</p>
            <%=new java.util.Date()%>
        </footer>
        </hr>
    </body>
</html>
