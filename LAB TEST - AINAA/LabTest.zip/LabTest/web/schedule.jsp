<%-- 
    Document   : schedule
    Created on : 16 Jun 2026, 3:52:35 PM
    Author     : MP2-4
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ include file="header.html" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Schedule</title>
    </head>
    <body>
        <table>
            <tr>
                <td>Student Name</td>
                <td>Branch Location</td>
                <td>Lesson Type</td>
                <td>Status</td>
                
            </tr>
        </table>
        <%@ include file="footer.jsp" %>
    </body>
</html>
