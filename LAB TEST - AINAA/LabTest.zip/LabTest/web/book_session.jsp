<%-- 
    Document   : book_session
    Created on : 16 Jun 2026, 3:18:56 PM
    Author     : MP2-4
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ include file="header.html" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Book Session</title>
        <link rel="stylesheet" 
              href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" 
              integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" 
              crossorigin="anonymous">
    </head>
    <body>
        <header>
           <nav class="navbar navbar-expand-md navbar-dark"
                style="background-color: activeborder">
               <div>
                   <a href="" class="navbar-brand"> Book Session </a>
               </div>
               
               <ul class="navbar-nav">
                   <li><a href="<%=request.getContextPath()%>/NewServlet"
                          class="nav-link">Book</a></li>
               </ul>
           </nav>   
        </header>
                          <br>
        <div class="container col-md-5">
            <div class="card">
                <div class="card-body">
                    <c:if test="${Training_Session != null}">
                        <form action="<%=request.getContextPath()%>/NewServlet" method="post">
                    </c:if>
                    <c:if test="${Training_Session == null}">
                        <form action="<%=request.getContextPath()%>/NewServlet" method="post">
                    </c:if>
                        
                        <h2>
                            <c:if test="${Training_Session != null}">
                                Edit Booking
                            </c:if>
                            <c:if test="${Training_Session == null}">
                                Add New Booking
                            </c:if>
                        </h2>
                            <c:if test="${Training_Session != null}">
                            <input type="hidden" name="session_id" value="<c:out value='${Training_Session.session_id}' default='0' />" />
                        </c:if>
                        
                        <fieldset class="form-group">
                            <label>Student Name</label>
                            <input type="text" value="<c:out value='${Training_Session.student_name}' />"
                                   class="form-control" name="student_name"
                                   required="required">
                        </fieldset>
                                   
                        <fieldset class="form-group">
                            <label>Branch Location</label>
                            <input list="branchLocationList" id="branch_location"
                                   class="form-control"
                                   name="branch_location" value="<c:out value='${Training_Session.branch_location}' />">
                            <datalist id="branchLocationList">
                                <option value="Kuala Lumpur">
                                <option value="Penang">
                                <option value="Johor">
                            </datalist>
                                      
                        <fieldset class="form-group">
                            <label>Lesson Type</label>
                            <input list="lessonTypeList" id="lesson_type"
                                   class="form-control"
                                   name="lesson_type" value="<c:out value='${Training_Session.lesson_type}' />">
                            <datalist id="lessonTypeList">
                                <option value="Manual Car">
                                <option value="Automatic Car">
                                <option value="Motorcycle">
                            </datalist>
                        </fieldset>
                            
                        <fieldset class="form-group">
                            <label>Status</label>
                            <input list="statusList" id="status"
                                   class="form-control"
                                   name="status" value="<c:out value='${Training_Session.status}' />">
                            <datalist id="statusList">
                                <option value="Booked">
                                <option value="Completed">
                            </datalist>
                        </fieldset>
                            <button type="submit" class="btn btn-success">Save<a href="<%=request.getContextPath()%>/NewServlet"</button>
                                                <%@ include file="footer.jsp" %>
            </body>
</html>
