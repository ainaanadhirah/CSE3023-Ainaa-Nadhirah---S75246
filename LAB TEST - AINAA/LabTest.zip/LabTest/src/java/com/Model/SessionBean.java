/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Model;

/**
 *
 * @author MP2-4
 */
public class SessionBean {
    public int session_id;
    public String student_name;
    public String branch_location;
    public String lesson_type;
    public String status;
    
    public SessionBean(){}
    
    public SessionBean(String student_name, String branch_location, String lesson_type, String status){
        this.student_name = student_name;
        this.branch_location = branch_location;
        this.lesson_type = lesson_type;
        this.status = status; 
    }
    
    public SessionBean(int session_id, String student_name, String branch_location, String lesson_type, String status){
        this.session_id = session_id;
        this.student_name = student_name;
        this.branch_location = branch_location;
        this.lesson_type = lesson_type;
        this.status = status; 
    }
    
    public int getsessionId(){
        return session_id;
    }
    
    public void setsessionId(int session_id){
        this.session_id = session_id;
    }
    
    public String getstudentName(){
        return student_name;
    }
    
    public void setstudentName(String student_name){
        this.student_name = student_name;
    }
    
    public String getbranchLocation(){
        return branch_location;  
    }
    
    public void setbranchLocation(String branch_location){
        this.branch_location = branch_location;
    }
    
    public String getlessonType(){
        return lesson_type;
    }
    
    public void setlessonType(String lesson_type){
        this.lesson_type = lesson_type;
    }
    
    public String getStatus(){
        return status;
    }
    
    public void setStatus(String status){
        this.status = status;
    }
}
