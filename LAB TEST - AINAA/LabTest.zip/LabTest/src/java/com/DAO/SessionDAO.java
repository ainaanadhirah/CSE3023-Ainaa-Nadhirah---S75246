/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.Model.SessionBean;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author MP2-4
 */
public class SessionDAO {
    Connection connection = null;
    private String jdbcURL = "jdbc:mysql://localhost:3306/drivesmart_db";
    private String jdbcUsername = "root";
    private String jdbcPassword = "";
    
    private static final String INSERT_TRAINING_SESSIONS_SQL = "INSERT INTO "
        + "Training_Sessions (student_name, branch_location, lesson_type, status ) VALUES " + " (?, ?, ?, ?);";
    
    private static final String SELECT_TRAINING_SESSIONS_BY_ID = "select session_id,"
            + "student_name ,branch_location ,lesson_type, status from Training_Sessions where session_id =?";
    
    private static final String SELECT_ALL_TRAINING_SESSIONS = "select * from Training_Sessions";
    
    private static final String DELETE_TRAINING_SESSIONS_SQL = "delete from "
        + "Training_Sessions where session_id = ?;";
   
    private static final String UPDATE_TRAINING_SESSIONS_SQL = "update "
        + "Training_Sessions set student_name = ?, branch_location = ?, lesson_type = ?, status = ? where session_id = ?;";
    
     public SessionDAO(){}
    
    protected Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL,
                    jdbcUsername, jdbcPassword);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return connection;
    }
    
    public void bookSession(SessionBean session) throws SQLException {
        System.out.println(INSERT_TRAINING_SESSIONS_SQL);
        // try-with-resource statement will auto close the connection.
        try (Connection connection = getConnection();
                PreparedStatement preparedStatement = connection.
                        prepareStatement(INSERT_TRAINING_SESSIONS_SQL)) {
            preparedStatement.setString(1, session.getstudentName());
            preparedStatement.setString(2, session.getbranchLocation());
            preparedStatement.setString(3, session.getlessonType());
            preparedStatement.setString(4, session.getStatus());
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }
    public List<SessionBean> getAllTraining_Sessions() {
        List<SessionBean> Training_Sessions = new ArrayList<>();
        String sql = "SELECT * FROM Training_Sessions" +
                    "ORDER BY branch_location ASC";
        // Step 1: Establishing a Connection
        try (Connection connection = getConnection();
                // Step 2: Create a statement using connection object
                PreparedStatement preparedStatement = connection.
                        prepareStatement(SELECT_ALL_TRAINING_SESSIONS);) {
            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            ResultSet rs = preparedStatement.executeQuery();

            // Step 4: Process the ResultSet object.
            while (rs.next()) {
                int session_id = rs.getInt("session_id");
                String student_name = rs.getString("student_name");
                String branch_location = rs.getString("branch_location");
                String lesson_type = rs.getString("lesson_type");
                String status = rs.getString("status");
                
                Training_Sessions.add(new SessionBean (session_id, student_name, branch_location, lesson_type, status ));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return Training_Sessions;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException)
                        e).getSQLState());
                
                System.err.println("Error Code: " + ((SQLException)
                        e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
